#ifndef u_h_
#define u_h_

#define uchar unsigned char 
#define uint unsigned int

#include<reg52.h>
#include<intrins.h>
#include"nrf_MC.h"
#include"18b20.h"


#endif